import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-welcome-page',
  templateUrl: './welcome-page.component.html',
  styleUrls: ['./welcome-page.component.css'],
})
export class WelcomePageComponent implements OnInit {
  public welcomeForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private route: Router) {}

  ngOnInit(): void {
    this.welcomeForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
    });
  }

  startTheTest(form: FormGroup) {
    localStorage.setItem('username', form.value.email);
    console.log("Content");
    this.route.navigate(['/question']);
  }
}
