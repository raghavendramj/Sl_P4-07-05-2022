import { Component, OnInit } from '@angular/core';
import { Question } from 'src/app/models/question';
import { QuestionService } from 'src/app/services/question.service';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css'],
})
export class QuestionComponent implements OnInit {
  username: string = '';
  quizCompleted: boolean = false;
  pointsScored: number = 0;
  currentQuest: number = 0;
  questions: Question[] = [];
  constructor(private questionService: QuestionService) {}

  ngOnInit(): void {
    this.username = localStorage.getItem('username');
    this.questionService.getQuestions().subscribe((data) => {
      console.log(data);
      this.questions = data;
    });
  }

  answer(nextQuestionIndex, selectedOption) {}
}
