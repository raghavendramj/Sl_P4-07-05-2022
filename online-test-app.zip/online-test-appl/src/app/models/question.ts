import { Option } from './option';

export interface Question {
  qtext: string;
  options: Option[];
}
