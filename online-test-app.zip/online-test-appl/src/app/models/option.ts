export interface Option {
  otext: string;
  correct?: boolean;
}
