import { DigitcountPipe } from './digitcount.pipe';

describe('DigitcountPipe', () => {
  it('create an instance', () => {
    const pipe = new DigitcountPipe();
    expect(pipe).toBeTruthy();
  });
});
