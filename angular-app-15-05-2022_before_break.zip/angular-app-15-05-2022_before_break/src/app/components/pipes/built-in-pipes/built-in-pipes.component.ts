import { Component, OnInit } from '@angular/core';
import { Observable, Observer } from 'rxjs';

@Component({
  selector: 'app-built-in-pipes',
  templateUrl: './built-in-pipes.component.html',
  styleUrls: ['./built-in-pipes.component.css'],
})
export class BuiltInPipesComponent implements OnInit {
  public presentDate: Date = new Date();
  public price = 20000;
  completed = false;
  public fruits: string[] = [
    'Apple',
    'Orange',
    'Grapes',
    'Mango',
    'Kiwi',
    'Pomegranate',
  ];
  public person = {
    name: 'Kevin',
    country: 'England',
    email: 'kevin@gmail.com',
  };
  constructor() {}

  ngOnInit(): void {}

  timeChange = new Observable<string>((observer: Observer<string>) => {
    setInterval(() => observer.next(new Date().toString()), 1000);
  });
}
