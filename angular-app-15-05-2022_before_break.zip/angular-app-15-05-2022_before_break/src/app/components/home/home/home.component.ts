import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  public title: string = 'Angular 10';
  public isDisabled: boolean = true;
  public emailAddress: string = 'raghav@gmail.com';
  public testClass = ['testFont', 'decorate', 'italic'];
  public applyRedColor: boolean = false;
  public applyBlueColor: boolean = false;
  public customStyle:string = 'color:blue; font-size: 30px; text-decoration:line-through';


  onlyOneClass = 'oneBoldClass';
  multipleClasses = ['mulitBolder', 'multiFonter', 'multiItalic']
  constructor() {}

  ngOnInit(): void {}

  enableUsername(): void {
    console.log('Click works!');
    this.isDisabled = !this.isDisabled;
    console.log('Value of Email Address: - ', this.emailAddress);
  }

  changeColor() {
    this.applyRedColor = !this.applyRedColor;
    this.applyBlueColor = !this.applyBlueColor;
  }
}
