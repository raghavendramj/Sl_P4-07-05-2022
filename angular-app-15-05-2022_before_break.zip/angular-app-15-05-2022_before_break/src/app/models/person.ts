export interface Person {
  name: string;
  country: string;
  email: string;
}
