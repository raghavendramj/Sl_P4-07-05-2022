import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AttributeComponent } from './components/directive-usage/attribute/attribute.component';
import { StructuralComponent } from './components/directive-usage/structural/structural.component';
import { TemplateDrivenFormComponent } from './components/forms/template-driven-form/template-driven-form.component';
import { HomeComponent } from './components/home/home/home.component';
import { ParentComponent } from './components/interactions/parent/parent/parent.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { BuiltInPipesComponent } from './components/pipes/built-in-pipes/built-in-pipes.component';
import { PostsComponent } from './components/service-usage/posts/posts.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'pipes', component: BuiltInPipesComponent },
  { path: 'structural', component: StructuralComponent },
  { path: 'attribuite', component: AttributeComponent },
  { path: 'directives', component: StructuralComponent },
  { path: 'interactions', component: ParentComponent },
  { path: 'posts', component: PostsComponent },
  { path: 'tmpdrvform', component: TemplateDrivenFormComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent },
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
