import { Component, OnInit } from '@angular/core';
import { filter, from, fromEvent, of, range } from 'rxjs';

@Component({
  selector: 'app-observable',
  templateUrl: './observable.component.html',
  styleUrls: ['./observable.component.css'],
})
export class ObservableComponent implements OnInit {
  public numbers: number[] = [];
  public sum: number = 0;
  public filterdSum: number = 0;

  public filteredNumbers: number[] = [];

  constructor() {}

  ngOnInit(): void {
    //Observable
    const numbers$ = from([1, 2, 3, 4, 5, 6, 7, 8, 10]); //static /dynamic -> RESPONSE out of a API call

    //Observer
    const observer = {
      next: (num: number) => {
        this.numbers.push(num);
        this.sum += num;
      },
      error: (err: any) => {
        console.log('Error occurred !');
      },
      complete: () => {
        console.log('Observation completed!');
      },
    };

    //Link between Observable and the Observer
    numbers$.subscribe(observer);

    const filterFn = filter((num: number) => num % 2 != 0);
    const filteredNumbersLocal = filterFn(numbers$);
    filteredNumbersLocal.subscribe((num: number) => {
      console.log(num);
      this.filteredNumbers.push(num);
      this.filterdSum += num;
    });
  }
}
