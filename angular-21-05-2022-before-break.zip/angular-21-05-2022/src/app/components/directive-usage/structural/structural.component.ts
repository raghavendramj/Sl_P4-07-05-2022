import { Component, OnInit } from '@angular/core';
import { Person } from 'src/app/models/person';

@Component({
  selector: 'app-structural',
  templateUrl: './structural.component.html',
  styleUrls: ['./structural.component.css'],
})
export class StructuralComponent implements OnInit {
  public people: Person[] = [];
  trackByPerson(index: number, personArr: Person) {
    console.log('index : ', index, ' personArr.name :- ', personArr.name);
    return personArr.name;
  }
  public showData: true;
  public isUserLoggedIn = false;
  public showLoggedOutMessage = true;

  public names: string[] = ['Amit', 'Satya', 'Ayman', 'Hari'];

  public loginName:string = '';

  constructor() {}

  ngOnInit(): void {}

  loadData() {
    this.people = [
      {
        name: 'Kevin',
        country: 'England',
        email: 'kevin@gmail.com',
      },
      {
        name: 'Patty',
        country: 'Australia',
        email: 'patty@gmail.com',
      },
      {
        name: 'Ricky',
        country: 'South Africa',
        email: 'ricky@gmail.com',
      },
      {
        name: 'Kapil',
        country: 'India',
        email: 'kapil@gmail.com',
      },
    ];
  }
}


