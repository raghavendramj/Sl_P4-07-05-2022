import { Component, OnInit } from '@angular/core';
import { Todo } from 'src/app/models/todo';
import { PostsService } from 'src/app/services/posts.service';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css'],
})
export class PostsComponent implements OnInit {
  public todos: Todo[] = [];
  public loadData: true;

  //Injecting the PostsService service -> allow all the methods here to use.
  constructor(private postsService: PostsService) {}
  ngOnInit(): void {}

  loadTodosData() {
    this.postsService.getPosts().subscribe((data:Todo []) => {
      console.log('data : ', data);
      console.log('typeof : ', typeof data);
      this.todos = data;
    });
  }
}
