import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-driven-form',
  templateUrl: './template-driven-form.component.html',
  styleUrls: ['./template-driven-form.component.css'],
})
export class TemplateDrivenFormComponent implements OnInit {
  countries: Country[] = [];

  constructor() {}

  ngOnInit(): void {
    this.countries = [
      { id: 1, name: 'India' },
      { id: 2, name: 'Australia' },
      { id: 3, name: 'England' },
      { id: 4, name: 'USA' },
      { id: 5, name: 'South Africa' }
    ];
  }

  submitFields(contactForm) {
    console.log(contactForm.value);
  }
}
export class Country {
  id: number;
  name: string;
}
