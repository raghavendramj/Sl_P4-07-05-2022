import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home/home.component';
import { ParentComponent } from './components/interactions/parent/parent/parent.component';
import { ChildComponent } from './components/interactions/child/child/child.component';
import { StructuralComponent } from './components/directive-usage/structural/structural.component';
import { AttributeComponent } from './components/directive-usage/attribute/attribute.component';
import { CustomStyleDirective } from './directives/custom-style.directive';
import { BuiltInPipesComponent } from './components/pipes/built-in-pipes/built-in-pipes.component';
import { DigitcountPipe } from './pipes/digitcount.pipe';
import { CustomPipeComponent } from './components/pipes/custom-pipe/custom-pipe.component';
import { ObservableComponent } from './components/rxjs/observable/observable.component';
 

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ParentComponent,
    ChildComponent,
    StructuralComponent,
    AttributeComponent,
    BuiltInPipesComponent,
    CustomPipeComponent,
    CustomStyleDirective,
    DigitcountPipe,
    ObservableComponent
  ],
  imports: [BrowserModule, AppRoutingModule, FormsModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
